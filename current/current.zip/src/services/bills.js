/**
 * Remi Parayao
 * I&C SCI_X472.15: Sever-side development
 * 
 * 01/31/2020
 */

import knex from '../database'
// let initbills = new Array();

// let initData = [{id: 0, label: "Local-American Express", amount: 250.0, category: "Credit Card"}, 
//  			 {id: 1, label: "Local-Car Payment", amount:200.00, category: "Transportation"}, 
//  			 {id: 2, label: "Local-Electric", amount: 80.0, category: "Utilities"},
//  			 {id: 3, label: "Local-Water", amount: 30.0, category: "Utilities"}];

let initData;

function getMaxIndex(){
    return getBillItems().reduce((max, b) => Math.max(max, b.index), initData[0].index);
}

const getBillItems = async () => {
    await initData ? initData: getBillItemsFromDB();
}


//FOR EXPORT
export const getBillItemsFromDB = async() => {
    if (initData === undefined) {
        initData = await knex.select().from('monthly');
    }
    return initData ? initData : {};
}


export const deleteBillItem = async id =>{
    const data = initData.find(bill => bill.id ===id);
    if (data !== undefined){
        console.log('About to delete ' + JSON.stringify(data));
        await knex('monthly').where('id', data.id).del();
    }
    return data ? data : {};
}


//update array with newly created bill item
export const addBillItem = (label, category, amount) =>{
    const index = getMaxIndex() + 1;
    if (label && category && amount){
        let newBill = {index, label, category, amount};
        initData.push(newBill);
        return newBill;
    }
}
//FOR EXPORT
