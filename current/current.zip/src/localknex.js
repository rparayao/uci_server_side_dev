module.exports  = {
    development: {
        client: 'mysql',
        connection: {
            database: 'budget_tracker',
            user: 'root',
            password: ''
        }
    },
    developmentx: {
        client: 'mysql',
        connection: {
            database: 'monthly-bills',
            user: 'postgres',
            password: 'postgrespw'
        }
    }

};